
local events = {}

events.LISTENER = "LISTENER"

return events
