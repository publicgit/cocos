
local UmengAliasType = {
	SINA_WEIBO = "SINA_WEIBO";
	TENCENT_WEIBO = "TENCENT_WEIBO";
	QQ = "QQ";
	WEIXIN = "WEIXIN";
	BAIDU = "BAIDU";
	RENREN = "RENREN";
	KAIXIN = "KAIXIN";
}

return UmengAliasType
