
luaoc = require(cc.PACKAGE_NAME .. ".luaoc")

function device.showAlertIOS(title, message, buttonLabels, listener)
end
